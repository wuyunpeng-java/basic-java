create
    definer = root@localhost function myf1(empName varchar(10)) returns double
begin
  declare sal double ;
  select 
    emp.`工资` into sal 
  from
    emp 
  where emp.`name` = empName ;return sal ;
end;


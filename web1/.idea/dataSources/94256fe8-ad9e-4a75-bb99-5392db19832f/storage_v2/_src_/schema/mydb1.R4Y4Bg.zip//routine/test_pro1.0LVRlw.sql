create
    definer = root@localhost procedure test_pro1(IN id int, OUT NAME varchar(20))
BEGIN
SELECT `dep_name`  INTO NAME
FROM department
WHERE department.`id`=id;
END;

